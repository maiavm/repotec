<?php 

	

	  
// 	    $name = $_POST['name'];
// 	    $email =  $_POST['email'];
// 	    $mobile = $_POST['mobile'];
	  
// 	 echo($name.' '.$email.' '.$mobile);
	    
	    
	

	

	    
	    
	    ?>