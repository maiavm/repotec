<html>

<head>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <title>Repo</title>
</head>

<body style="  background-color:#ffffe6 ">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>

     <div style=" align-items: center; background-color:red;"><h1>Meu título</h1>
    <h2>Ola eu sou Eliéser</h2>
    <p>Clique abaixo e fale comigo</p>
  </div>   

    
    <div class="btn-group">
        <button type="button" class="btn btn-success dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
            selecione
        </button>
        <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Action</a></li>
            <li><a class="dropdown-item" href="#">Another action</a></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
            <li>
                <hr class="dropdown-divider">
            </li>
            <li><a class="dropdown-item" href="#">Separated link</a></li>
        </ul>
    </div>

    <form class="row row-cols-lg-auto g-3 align-items-center" fe sem_remove>
        <div class="col-12">
            <label class="visually-hidden" for="inlineFormInputGroupUsername">Username</label>
            <div class="input-group">
                <div class="input-group-text">PESQUISAR:</div>
                <input type="text" class="form-control" id="inlineFormInputGroupUsername" placeholder="Digite Aqui">
                <button type="submit" class="btn btn-success" style="background-color: #ff4d4d; border-color:#b30000 ;  ">Pesquisar</button>
            </div>
        </div>

    </form>













    <div class="album py-5 bg-light">
        <div class="container">

            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">


            <?php   
            $titulo = "Titulo ";    
            $caminho = "/repo/PDFs/";
            $parte1 = "http://www."; 
            $parte2 = "google.com";
            $link = $parte1 . $parte2; 
            $i = 0;
            while($i <= 10){

                    echo   '<div class='."col".'>
                                <div class='."card shadow-sm".'>
                                    <svg class='."bd-placeholder-img card-img-top".' width='."100%".' height='."225".'xmlns='."http://www.w3.org/2000/svg".' role='."img".'aria-label='."Placeholder: Thumbnail".' preserveAspectRatio='."xMidYMid slice".' focusable='."false".'><title>Placeholder</title><rect width='."100%".' height='."100%" .'fill='."##0d6efd".'/><text x='."50%".' y='."50%".' fill='."#eceeef".' dy='.".3em".'>'.'</text></svg>'.

                        '<div class='."card-body".'>
                            <p class='."card-text".'>'.$titulo. $i.'</p>
                        <div class='."d-flex justify-content-between align-items-center".'>
                        <div class='."btn-group".'>
                  <button type='."button" .'class='."btn btn-sm btn-outline-secondary".'>View</button>
                  <button type='."button".' class='."btn btn-sm btn-outline-secondary".'>'.'Edit</button>
                </div>
                <small class='."text-muted".'>9 mins</small>
              </div>
            </div>
        </div>
    </div>';
   
            
                $i=$i+1;


            }



                  
             ?>        


                
   

    








</body>

</html>
 